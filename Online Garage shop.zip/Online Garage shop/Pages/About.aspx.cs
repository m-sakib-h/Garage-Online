﻿using System;

namespace Pages
{
    public partial class Pages_About : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}